const baseUrl = String(process.env.SUPABASE_URL || '').replace(/\/$/, '');
const apiKey = process.env.SUPABASE_ANON_KEY || process.env.SUPABASE_PUBLISHABLE_KEY || process.env.SUPABASE_SECRET_KEY || '';

function assertConfigured() {
  if (!baseUrl || !apiKey) {
    const error = new Error('Supabase authentication is not configured on the server.');
    error.status = 500;
    throw error;
  }
}

async function supabaseRequest(path, options = {}) {
  assertConfigured();
  const response = await fetch(`${baseUrl}${path}`, {
    ...options,
    headers: {
      apikey: apiKey,
      'Content-Type': 'application/json',
      ...(options.headers || {})
    }
  });
  const text = await response.text();
  let data = {};
  try { data = text ? JSON.parse(text) : {}; } catch { data = { message: text }; }
  return { response, data };
}

async function signInWithPassword(email, password) {
  const { response, data } = await supabaseRequest('/auth/v1/token?grant_type=password', {
    method: 'POST',
    body: JSON.stringify({ email, password })
  });
  return { data: response.ok ? data : null, error: response.ok ? null : data };
}

async function signUp(email, password, name) {
  const { response, data } = await supabaseRequest('/auth/v1/signup', {
    method: 'POST',
    body: JSON.stringify({ email, password, data: { name } })
  });
  return { data: response.ok ? data : null, error: response.ok ? null : data };
}

async function getUser(accessToken) {
  if (!accessToken) return { user: null, error: null };
  const { response, data } = await supabaseRequest('/auth/v1/user', {
    method: 'GET',
    headers: { Authorization: `Bearer ${accessToken}` }
  });
  return { user: response.ok ? data : null, error: response.ok ? null : data };
}

module.exports = { signInWithPassword, signUp, getUser };
