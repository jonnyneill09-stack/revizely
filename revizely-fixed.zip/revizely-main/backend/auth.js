const { getUser } = require('./supabase');

const SESSION_COOKIE = 'revizely_session';
const SECURE_COOKIE = Boolean(process.env.VERCEL) || process.env.NODE_ENV === 'production';

function cookieAttributes(maxAge) {
  return `HttpOnly; Path=/; SameSite=Lax; Max-Age=${maxAge}${SECURE_COOKIE ? '; Secure' : ''}`;
}

function rolesFor(email) {
  const roles = ['student'];
  const listed = (key) => String(process.env[key] || '')
    .split(',').map((entry) => entry.trim().toLowerCase()).filter(Boolean).includes(email);
  if (listed('CREATOR_EMAILS')) roles.push('creator');
  if (listed('ADMIN_EMAILS')) roles.push('admin');
  return roles;
}

function normaliseEmail(value) { return String(value || '').trim().toLowerCase(); }

function parseCookies(request) {
  return Object.fromEntries(
    String(request.headers.cookie || '')
      .split(';').map((part) => part.trim().split('='))
      .filter(([key]) => key)
      .map(([key, ...value]) => [key, decodeURIComponent(value.join('='))])
  );
}

async function getSessionUser(request) {
  const token = parseCookies(request)[SESSION_COOKIE];
  if (!token) return null;
  try {
    const { user, error } = await getUser(token);
    if (error || !user) return null;
    const email = normaliseEmail(user.email);
    return {
      id: user.id,
      name: user.user_metadata?.name || email.split('@')[0] || 'Student',
      email: user.email,
      friendCode: user.user_metadata?.friendCode || '',
      roles: rolesFor(email),
      createdAt: user.created_at
    };
  } catch {
    return null;
  }
}

function createSession(user, response, session) {
  if (!session?.access_token) return;
  response.setHeader('Set-Cookie', `${SESSION_COOKIE}=${encodeURIComponent(session.access_token)}; ${cookieAttributes(604800)}`);
}

function clearSession(request, response) {
  response.setHeader('Set-Cookie', `${SESSION_COOKIE}=; ${cookieAttributes(0)}`);
}

function publicUser(user) {
  return { id: user.id, name: user.name, email: user.email, friendCode: user.friendCode || '', roles: user.roles || ['student'] };
}

module.exports = { clearSession, rolesFor, createSession, getSessionUser, normaliseEmail, publicUser };
